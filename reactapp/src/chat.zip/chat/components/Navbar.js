import React from 'react';
import './main.css';

const Navbar = () => {
    return (
       
        <div className='navbar'>
            <span className='logo'>
                Connect
            </span>

            <div className='user'>
                <img src='' alt=''/>
                <span>Sriram</span>
                
            </div>
        </div>
    );
}

export default Navbar;
