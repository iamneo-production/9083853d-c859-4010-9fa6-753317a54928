import React from 'react';

const Message = () => {
    return (
        <div className='message-owner'>
            
            <div className='messageContent' style={{marginLeft:'3%'}}>
            
                <p className='p' >hello</p>
                </div>
                
        </div>
    );
}

export default Message;
